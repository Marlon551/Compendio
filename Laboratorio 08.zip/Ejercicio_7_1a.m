%% generateMessage .m
% Generates binary bit sequence for transmitting ASCII text with Ettus B200 USRP .
%
% Cory J. Prust , Ph.D.
% Last Modified : 7/18/2018

clear all;
close all;

%% Create message.
a = dec2bin('MSOE University \n', 8);
numChars = size(a, 1);

% Convert binary strings into vectors
a = a - '0';

% Reshape into a vector of bits; 8 bits per character
a = reshape(a.', 8 * numChars, 1)';

%% Build transmit packet
pre = [0 0 0 0 1 1 1 1 0 0 0 0 1 1 1 1];
message = [pre a];
numSymsTot = length(message);